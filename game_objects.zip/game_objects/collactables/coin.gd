extends Area2D


func _ready() -> void:
	print("Coin spawned")

func _body_entered(body: Node2D) -> void:
	#if body.is_in_group("player"):
	print("Player entered the area!")
	queue_free()
